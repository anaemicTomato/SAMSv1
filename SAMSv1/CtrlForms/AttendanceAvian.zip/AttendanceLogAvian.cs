﻿// CtrlForms/AttendanceLogAvian.cs
using DevExpress.XtraEditors;
using DevExpress.XtraReports.UI;
using SAMSv1.Data;
using SAMSv1.Helpers;
using SAMSv1.Models;
using SAMSv1.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SAMSv1.CtrlForms
{
    public partial class AttendanceLogAvian : DevExpress.XtraEditors.XtraUserControl
    {
        private readonly AttendanceRepository _repo = new AttendanceRepository();

        public AttendanceLogAvian()
        {
            InitializeComponent();
            this.Load += AttendanceLogAvian_Load;
        }

        // ── On Load: populate all dropdowns ──────────────────────────
        private void AttendanceLogAvian_Load(object sender, EventArgs e)
        {
            LoadEvents();
            LoadCourses();
            LoadYearLevels();
            EnableCalendarMultiSelect();

            // Wire up live-refresh triggers
            cbEvent.SelectedIndexChanged += (s, _) => RefreshGrid();
            cbCourse.SelectedIndexChanged += (s, _) => RefreshGrid();
            cbYearLevel.SelectedIndexChanged += (s, _) => RefreshGrid();
            ccCalendar.DateTimeChanged += (s, _) => RefreshGrid();

            // Wire up search box
            scSearchStudent.Properties.Client = gcStudentTable;

            // Wire up report button
            btnGenerateReport.Click += btnGenerateReport_Click;
        }

        private void LoadEvents()
        {
            var events = _repo.GetAllEvents().ToList();
            cbEvent.Properties.Items.Clear();
            cbEvent.Properties.Items.Add("All Events");  // default
            foreach (var ev in events)
                cbEvent.Properties.Items.Add(ev);        // stores Event object

            cbEvent.SelectedIndex = 0;
        }

        private void LoadCourses()
        {
            cbCourse.Properties.Items.Clear();
            cbCourse.Properties.Items.Add("All");
            foreach (var c in _repo.GetAllCourses())
                cbCourse.Properties.Items.Add(c);
            cbCourse.SelectedIndex = 0;
        }

        private void LoadYearLevels()
        {
            cbYearLevel.Properties.Items.Clear();
            cbYearLevel.Properties.Items.Add("All");
            foreach (var y in _repo.GetAllYearLevels())
                cbYearLevel.Properties.Items.Add(y);
            cbYearLevel.SelectedIndex = 0;
        }

        private void EnableCalendarMultiSelect()
        {
            // Allows clicking multiple dates on the calendar
            ccCalendar.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Classic;
            // NOTE: DevExpress CalendarControl does NOT natively support
            // date-range drag-select. For a range, use two DateEdit controls
            // (From / To). If you want that, let me know and I'll add it.
        }

        // ── Helpers to read current filter state ─────────────────────
        private List<string> GetSelectedDates()
        {
            // CalendarControl gives you one selected date
            var date = ccCalendar.DateTime;
            if (date == DateTime.MinValue) return new List<string>();
            return new List<string> { date.ToString("yyyy-MM-dd") };
        }

        private int? GetSelectedEventId()
        {
            if (cbEvent.SelectedItem is Event ev) return ev.EventID;
            return null; // "All Events" selected
        }

        private string GetSelectedCourse()
            => cbCourse.SelectedItem?.ToString();

        private string GetSelectedYearLevel()
            => cbYearLevel.SelectedItem?.ToString();

        // ── Live grid refresh ─────────────────────────────────────────
        private void RefreshGrid()
        {
            var rows = _repo.GetAttendance(
                GetSelectedDates(),
                GetSelectedEventId(),
                GetSelectedCourse(),
                GetSelectedYearLevel());

            gcStudentTable.DataSource = rows.ToDataTable();
        }

        // ── Generate Report button ────────────────────────────────────
        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            var dates = GetSelectedDates();
            var eventId = GetSelectedEventId();
            var course = GetSelectedCourse();
            var yearLevel = GetSelectedYearLevel();

            if (dates.Count == 0)
            {
                XtraMessageBox.Show(
                    "Please select a date on the calendar first.",
                    "No Date Selected",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Warning);
                return;
            }

            var report = new StudentRPT(dates, eventId, course, yearLevel);
            report.ShowPreviewDialog();
        }
    }
}